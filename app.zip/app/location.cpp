#include <cmath>
#include <iostream>
#include <string>

//Funtion definitions, and declarations.

const double R = 3959.9;

//Formula to calculate the formula
double formula(double lat1, double lat2, double lon1, double lon2)
{

    double x = lat1 - lat2; //Distnce in latitudes
    double dlat = x * (M_PI/180);

    double y = lon1 - lon2; //Distance in longtitudes
    double dlon = y * (M_PI/180);
    double a,c,d;

    a = sin(dlat/2) * sin(dlat/2) + cos((lat1*M_PI/180)) * cos((lat2*M_PI/180)) * sin(dlon/2) * sin(dlon/2);
    c = 2 * atan2(sqrt(a), sqrt(1-a));
    d = R * c;

    return d;
}

//Check either the latitude has South or not.
//If so make it negative.
void southOrNorth(std::string x, double *y)
{
    if(x.find("S") != std::string::npos)
    {
        *y = -*y;   //Change the value of the double in that address.
    }
}

//Start Location output:
void outputStart(std::string a1, std::string b1, std::string c1)
{
    std::cout << "Start Location: " << a1 << " " << b1 << " (" << c1 << ")" << std::endl;
}

//Closest Location output:
void outputClosest(std::string a2, std::string b2, std::string c2, double cL)
{
    std::cout << "Closest Location: " << a2 << " " << b2 << " (" << c2 << ")" << " (" << cL << " miles)" << std::endl;
}

//Farthest Location output:
void outputFarthest(std::string a3, std::string b3, std::string c3, double fL)
{
    std::cout << "Farthest Location: " << a3 << " " << b3 << " (" << c3 << ")" << " (" << fL << " miles)" << std::endl;
}

//compare the closest and farthest if they are not equal!
void compare(double *temp, double *closest, double *farthest, std::string x, std::string y, std::string z, std::string *gotLat1 , std::string *gotLat2, std::string *gotLon1, std::string *gotLon2, std::string *gotAir1, std::string *gotAir2)
{
    //If the current temp distance value is bigger than previous,
    //then, new farthest distance is our temp value.
    if(*temp > *farthest)
    {
        *farthest = * temp;

        //Assigning values to categories.
        *gotLat2 = x;
        *gotLon2 = y;
        *gotAir2 = z;
    }
    else if(*temp <= *closest)      //If temp is equal or smaller than closest distance, then temp is the new closest.
    {
        *closest = *temp;

        //Assigning values to categories.
        *gotLat1 = x;
        *gotLon1 = y;
        *gotAir1 = z;
    }
}
