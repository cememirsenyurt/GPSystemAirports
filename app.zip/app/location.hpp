#ifndef LOCATION_HPP
#define LOCATION_HPP

double formula(double lat1, double lat2, double lon1, double lon2);
void southOrNorth(std::string x, double *y);
void outputStart(std::string a1, std::string b1, std::string c1);
void outputClosest(std::string a2, std::string b2, std::string c2, double cL);
void outputFarthest(std::string a3, std::string b3, std::string c3, double fL);
void compare(double *temp, double *closest, double *farthest, std::string x, std::string y, std::string z, std::string *gotLat1, std::string *gotLat2, std::string *gotLon1, std::string *gotLon2, std::string *gotAir1, std::string *gotAir2);
#endif
