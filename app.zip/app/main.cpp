#include <iostream>
#include <string>
#include <cmath>
#include "location.hpp"

int main()
{
    // Start with starting location,
    // where I split into 3 categories:

    std::string latitude;
    std::string longtitude;
    std::string airport;
    
    int targetLoc;  //We'll determine how many target locations will be.
    
    std::cin >> latitude >> longtitude;
    std::cin.ignore();
    std::getline(std::cin, airport);

    std::cin >> targetLoc;
    
    //Conversion of latitude and longtitude for calculations:
    //Get the numeric part from the string
    double startingLatDouble = std::stod(latitude);
    double startingLonDouble = std::stod(longtitude);

    //Those two are the closest and farthest distances in terms of miles.
    double closestLoc;
    double farthestLoc;

    //For closest and farthest locations,
    //I need 3 categories as I needed in start location:
    
    //For closest location
    std::string gotLat1;
    std::string gotLon1;
    std::string gotAir1;

    //For farthest location
    std::string gotLat2;
    std::string gotLon2;
    std::string gotAir2;
    
    //For loop to ask user to input targets they want
    for(int i=1 ; i<=targetLoc ; ++i)
    {
        //3 Categories for targets
        std::string targetLat;
        std::string targetLon;
        std::string targetAir;
        
        std::cin >> targetLat >> targetLon;
        std::cin.ignore();
        std::getline(std::cin, targetAir);
        
        //Getting numeric part from the string.
        double targetLatDouble = std::stod(targetLat);
        double targetLonDouble = std::stod(targetLon);
    
        //Check wheter it's in south or north
        //to be able to calculate the distance correctly.
        southOrNorth(targetLat, &targetLatDouble);
        
        //temp is the user input and we have to compare and store
        //in every cycle of the for loop.
        double temp = formula(startingLatDouble, targetLatDouble, startingLonDouble, targetLonDouble);

        //If user input is just 1,
        //that means our closest and farthest will be same.
        if(i == 1)
        {
            //So, I initialize the categories (latitude, longtitude, airport name)
            closestLoc = temp;
            farthestLoc = temp;
            gotLat1 = targetLat;
            gotLat2 = targetLat;

            gotLon1 = targetLon;
            gotLon2 = targetLon;

            gotAir1 = targetAir;
            gotAir2 = targetAir;
        }
        else
        {
            //Otherwise, the program compares the temp value with the current closestLoc and farthestLoc.
            compare(&temp, &closestLoc, &farthestLoc, targetLat, targetLon, targetAir, &gotLat1, &gotLat2, &gotLon1, &gotLon2, &gotAir1, &gotAir2);
            //I have local variables to compare, after I compare I have to initialize categories.
            //so I need their position to assign values (WITH POINTER). Otherwise, the values disappears,
            //if I don't use global variables, which I didn't use it!
        }

 }
       //output functions
       outputStart(latitude, longtitude, airport);
       outputClosest(gotLat1, gotLon1, gotAir1, closestLoc);
       outputFarthest(gotLat2, gotLon2, gotAir2, farthestLoc);

    return 0;
}

